package es.ucm.fdi.trabajo;

import org.junit.Test;
import static org.junit.Assert.*;

public class VisualizationTest {

}
