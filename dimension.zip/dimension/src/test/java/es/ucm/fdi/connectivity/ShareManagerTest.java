package es.ucm.fdi.connectivity;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Assert;

import es.ucm.fdi.workspace.project.ProjectManagerAS;
import es.ucm.fdi.workspace.project.ProjectTO;

public class ShareManagerTest {

	@Test
	public void shareImportTest() {
		
	}

	@Test
	public void findTest() {

	}
	
}
