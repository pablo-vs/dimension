package es.ucm.fdi.workspace.transformations;

import java.lang.Math;

/**
 * @author Inmapg
 * @author Eduardo Amaya
 * @author Javier Galiana
 *
 */

public class TransformarFuncion {
	
	protected final static double PI = Math.PI;
	protected final static double E = Math.E;
	protected static int ID;
	
	public TransformarFuncion(int newID){
		ID = newID;
	}
}
