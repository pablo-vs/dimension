package es.ucm.fdi.operations;

import org.junit.Test;

public class DonateTest {

	@Test
	public void donateTest() {
		DonateAS.donate();
	}
}
