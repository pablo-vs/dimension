# DIMENSION

Visualización de objetos n-dimensionales

[![Build Status](https://travis-ci.com/pablo-vs/dimension.svg?token=GSJFuf6yrwuW75X41Sc4&branch=master)](https://travis-ci.com/pablo-vs/dimension)
