package es.ucm.fdi.users;

/**
 * Represents the distinct types of users:
 * User and admin.
 */
public enum UserType {
	USER, ADMIN;
}
