package es.ucm.fdi.util;


/**
 * @author Arturo Acuaviva
 */

public class FunctionToGraph {

	
}
