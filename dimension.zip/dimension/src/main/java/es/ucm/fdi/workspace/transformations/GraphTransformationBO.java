package es.ucm.fdi.workspace.transformations;

import es.ucm.fdi.workspace.GraphBO;

public interface GraphTransformationBO {

	public void apply(GraphBO graph);
}
